// ui.js - UI-функции и вспомогательные

// ================ НОВАЯ ФУНКЦИЯ: РЕНДЕРИНГ СООБЩЕНИЙ С ГРУППИРОВКОЙ ПО ДАТАМ ================

function renderMessagesWithGrouping(messages) {
    if (!chatContainer) return;
    
    chatContainer.innerHTML = '';
    
    if (!messages || messages.length === 0) {
        return;
    }
    
    const sortedMessages = [...messages].sort((a, b) => 
        new Date(a.timestamp) - new Date(b.timestamp)
    );
    
    // Группируем сообщения по датам
    const groupedMessages = {};
    sortedMessages.forEach(msg => {
        const date = new Date(msg.timestamp);
        const dateKey = date.toLocaleDateString('ru-RU', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        if (!groupedMessages[dateKey]) {
            groupedMessages[dateKey] = [];
        }
        groupedMessages[dateKey].push(msg);
    });
    
    // Отображаем сообщения по группам
    Object.keys(groupedMessages).forEach(dateKey => {
        // Добавляем заголовок с датой
        const dateHeader = document.createElement('div');
        dateHeader.className = 'chat-group-header';
        dateHeader.textContent = dateKey;
        dateHeader.style.cssText = `
            text-align: center;
            margin: 20px 0;
            padding: 8px 0;
            border-bottom: 1px solid #e0e0e0;
            color: #666;
            font-size: 13px;
            font-weight: 600;
        `;
        
        chatContainer.appendChild(dateHeader);
        
        // Добавляем сообщения для этой даты
        groupedMessages[dateKey].forEach(msg => {
            if (msg.user === true || msg.role === 'user') {
                // Используем форматированное отображение для пользовательских сообщений
                addFormattedMessageToChat('user', msg.content);
            } else if (msg.server === true || msg.role === 'assistant') {
                addFormattedMessageToChat('assistant', msg.content);
            } else {
                // По умолчанию считаем сообщение от ассистента
                addFormattedMessageToChat('assistant', msg.content);
            }
        });
    });
    
    setTimeout(() => {
        if (chatContainer) {
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }
    }, 100);
}

// ================ НОВАЯ ФУНКЦИЯ: ФОРМАТИРОВАНИЕ ДАТЫ ДЛЯ ЧАТОВ ================

function formatChatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
        return 'Сегодня';
    } else if (diffDays === 1) {
        return 'Вчера';
    } else if (diffDays < 7) {
        const days = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
        return days[date.getDay()];
    } else {
        return date.toLocaleDateString('ru-RU', {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        });
    }
}

function addMessageToChat(role, content) {
    const messageElement = createMessageElement(role, content);
    if (chatContainer) {
        chatContainer.appendChild(messageElement);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }
}

function addFormattedMessageToChat(role, content) {
    const messageElement = createFormattedMessageElement(role, content);
    if (chatContainer) {
        chatContainer.appendChild(messageElement);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }
}




/////////////////////////////////////////////////////////////////////////////////////////////


function parseProgressFromString(content) {
    // Ищем паттерн (число*число) в конце или в любом месте строки
    const match = content.match(/\((\d+)\s*\*\s*(\d+)\)/);
    if (match && match[1] && match[2]) {
        const current = parseInt(match[1], 10);
        const total = parseInt(match[2], 10);
        if (total > 0) {
            const percent = Math.min(100, Math.round((current / total) * 100));
            return { current, total, percent };
        }
    }
    return null;
}

/**
 * Создаёт HTML для прогресс-бара
 */
function createProgressBarElement(current, total, percent) {
    const progressWrapper = document.createElement('div');
    progressWrapper.className = 'progress-wrapper';
    progressWrapper.style.cssText = `
        margin: 8px 0;
        max-width: 100px;
        background: #f0f2f5;
        width: 100%;   
        border-radius: 0px;
        overflow: hidden;
        font-size: 12px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.12);
    `;
    
    progressWrapper.innerHTML = `
        <div style="display: flex; justify-content: space-between; padding: 4px 8px; color: #666;">
            <span>${current} из ${total}</span>
            <span>${percent}%</span>
        </div>
        <div style="height: 16px; background: #e0e0e0;">
            <div style="
                height: 100%;
                width: ${percent}%;
                background: linear-gradient(90deg, #2196f3, #1976d2);
                transition: width 0.4s cubic-bezier(0.4, 0, 0.2, 1);
                box-shadow: inset 0 1px 2px rgba(255,255,255,0.3);
                border-radius: 0px;
            "></div>
        </div>
    `;
    return progressWrapper;
}

/**
 * Формирует контент сообщения с возможным прогресс-баром
 */
function createFormattedMessageContent(role, content) {
    const progressData = parseProgressFromString(content);
    
    // Удаляем техническую часть "(1*17)" из отображаемого текста
    const cleanContent = content.replace(/\s*\(\d+\s*\*\s*\d+\)/, '').trim();
    
    // Базовая разметка сообщения
    let html = `<div class="message-text">${cleanContent}</div>`;
    
    // Если есть прогресс — добавляем бар ПОСЛЕ текста
    if (progressData) {
        const progressHTML = createProgressBarElement(
            progressData.current,
            progressData.total,
            progressData.percent
        ).innerHTML;
        html += `<div class="message-progress">${progressHTML}</div>`;
    }
    
    return html;
}

/**
 * Основная функция: обновляет или создаёт сообщение в чате
 */
function changeFormattedMessageToChat(role, content, isUpdatable = false, messageId = 'task-progress') {
    let messageElement = null;
    
    // 🔍 Если сообщение обновляемое — ищем существующий элемент
    if (isUpdatable && messageId) {
        messageElement = document.querySelector(`[data-message-id="${messageId}"]`);
    }
    
    // ✨ Если элемент найден — обновляем контент
    if (messageElement) {
        const contentContainer = messageElement.querySelector('.message-content') || messageElement;
        contentContainer.innerHTML = createFormattedMessageContent(role, content);
        messageElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        return messageElement;
    }
    
    // 🆕 Если элемента нет — создаём новый
    messageElement = createFormattedMessageElement2(role, content);
    
    // Добавляем идентификатор для будущих обновлений
    if (isUpdatable && messageId) {
        messageElement.setAttribute('data-message-id', messageId);
    }
    
    if (chatContainer) {
        chatContainer.appendChild(messageElement);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }
    
    return messageElement;
}











//function changeFormattedMessageToChat(role, content, isUpdatable = false, messageId = 'task-progress') {
//    let messageElement = null;
//    
//    // 🔍 Если сообщение обновляемое — ищем существующий элемент
//    if (isUpdatable && messageId) {
//        messageElement = document.querySelector(`[data-message-id="${messageId}"]`);
//    }
//    
//    // ✨ Если элемент найден — обновляем контент
//    if (messageElement) {
//        const contentContainer = messageElement.querySelector('.message-content') || messageElement;
//        // Плавно обновляем текст (можно добавить анимацию при желании)
//        contentContainer.innerHTML = createFormattedMessageContent(role, content);
//        // Прокручиваем к обновлённому сообщению
//        messageElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
//        return messageElement;
//    }
//    
//    // 🆕 Если элемента нет — создаём новый как раньше
//    messageElement = createFormattedMessageElement2(role, content);
//    
//    // Добавляем идентификатор для будущих обновлений
//    if (isUpdatable && messageId) {
//        messageElement.setAttribute('data-message-id', messageId);
//    }
//    
//    if (chatContainer) {
//        chatContainer.appendChild(messageElement);
//        chatContainer.scrollTop = chatContainer.scrollHeight;
//    }
//    
//    return messageElement;
//}
//
//
///**
// * Возвращает HTML-контент сообщения (отделено от создания элемента для повторного использования)
// */
//function createFormattedMessageContent(role, content) {
//    // Экранируем HTML для безопасности, если контент от пользователя
//    const safeContent = content
//        .replace(/&/g, '&amp;')
//        .replace(/</g, '&lt;')
//        .replace(/>/g, '&gt;');
//    
//    // Здесь можно добавить форматирование: **жирный**, `код`, ссылки и т.д.
//    // Пример простого markdown-like парсинга:
//    return safeContent
//        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
//        .replace(/`([^`]+)`/g, '<code>$1</code>')
//        .replace(/\n/g, '<br>');
//}
//
//
function createFormattedMessageElement2(role, content) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message message-${role}`;
    
    // Контейнер для контента — на него будем ссылаться при обновлении
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.innerHTML = createFormattedMessageContent(role, content);
    
    messageDiv.appendChild(contentDiv);
    return messageDiv;
}

//
//
//
//
























function createMessageElement(role, content, id = null) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}-message`;
    if (id) messageDiv.id = id;
    
    const avatarDiv = document.createElement('div');
    avatarDiv.className = `avatar ${role}-avatar`;
    avatarDiv.textContent = role === 'user' ? '👤' : '🤖';
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    
    const bubbleDiv = document.createElement('div');
    bubbleDiv.className = 'message-bubble';
    bubbleDiv.textContent = content;
    
    // Контейнер для кнопок под сообщением
    const buttonsDiv = document.createElement('div');
    buttonsDiv.className = 'message-buttons';
    
    // Кнопка копирования (значок)
    const copyButton = document.createElement('button');
    copyButton.className = 'message-copy-btn';
    copyButton.innerHTML = '<i class="fas fa-copy"></i>';
    copyButton.title = 'Копировать сообщение';
    copyButton.onclick = function(e) {
    e.stopPropagation();
    e.preventDefault();
    
    // Берём текст из data-атрибута сообщения, чтобы избежать замыканий
    const msgBubble = this.closest('.message');
    const rawContent = msgBubble?.getAttribute('data-raw-content') || '';
    
    copyToClipboard(rawContent);
    
    const originalHTML = this.innerHTML;
    this.innerHTML = '<i class="fas fa-check"></i>';
    this.style.color = '#4CAF50';
    setTimeout(() => {
        this.innerHTML = originalHTML;
        this.style.color = '';
    }, 2000);
};
    
    buttonsDiv.appendChild(copyButton);
    
    // Кнопка сохранения в промты только для пользовательских сообщений (значок)
    if (role === 'user') {
        const savePromptButton = document.createElement('button');
        savePromptButton.className = 'message-save-btn';
        savePromptButton.innerHTML = '<i class="fas fa-bookmark"></i>';
        savePromptButton.title = 'Сохранить в личные промты';
        savePromptButton.onclick = function(e) {
            e.stopPropagation();
            // Автоматически генерируем название из первых 20 символов
            const name = content.substring(0, 20) + (content.length > 20 ? '...' : '');
            saveMessageToPromptsWithName(content, name);
            const originalHTML = this.innerHTML;
            this.innerHTML = '<i class="fas fa-check"></i>';
            setTimeout(() => {
                this.innerHTML = originalHTML;
            }, 2000);
        };
        
        buttonsDiv.appendChild(savePromptButton);
    }
    
    contentDiv.appendChild(bubbleDiv);
    contentDiv.appendChild(buttonsDiv);
    
    if (role === 'user') {
        messageDiv.appendChild(contentDiv);
        messageDiv.appendChild(avatarDiv);
    } else {
        messageDiv.appendChild(avatarDiv);
        messageDiv.appendChild(contentDiv);
    }
    
    return messageDiv;
}

function createFormattedMessageElement(role, content, id = null) {
    const messageDiv = document.createElement('div');
    messageDiv.setAttribute('data-raw-content', content);
    messageDiv.className = `message ${role}-message`;
    if (id) messageDiv.id = id;
    
    const avatarDiv = document.createElement('div');
    avatarDiv.className = `avatar ${role}-avatar`;
    avatarDiv.textContent = role === 'user' ? '👤' : '🤖';
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    
    const bubbleDiv = document.createElement('div');
    bubbleDiv.className = 'message-bubble';
    
    // Форматируем текст - ДЛЯ ВСЕХ СООБЩЕНИЙ (и пользовательских, и ассистента)
    bubbleDiv.innerHTML = formatText(content);
    
    // Контейнер для кнопок под сообщением
    const buttonsDiv = document.createElement('div');
    buttonsDiv.className = 'message-buttons';
    
    // Кнопка копирования (значок)
    const copyButton = document.createElement('button');
    copyButton.className = 'message-copy-btn';
    copyButton.innerHTML = '<i class="fas fa-copy"></i>';
    copyButton.title = 'Копировать сообщение';
    copyButton.onclick = function(e) {
    e.stopPropagation();
    e.preventDefault();
    
    // Берём текст из data-атрибута сообщения, чтобы избежать замыканий
    const msgBubble = this.closest('.message');
    const rawContent = msgBubble?.getAttribute('data-raw-content') || '';
    
    copyToClipboard(rawContent);
    
    const originalHTML = this.innerHTML;
    this.innerHTML = '<i class="fas fa-check"></i>';
    this.style.color = '#4CAF50';
    setTimeout(() => {
        this.innerHTML = originalHTML;
        this.style.color = '';
    }, 2000);
};
    
    buttonsDiv.appendChild(copyButton);
    
    // Кнопка сохранения в промты только для пользовательских сообщений (значок)
    if (role === 'user') {
        const savePromptButton = document.createElement('button');
        savePromptButton.className = 'message-save-btn';
        savePromptButton.innerHTML = '<i class="fas fa-bookmark"></i>';
        savePromptButton.title = 'Сохранить в личные промты';
        savePromptButton.onclick = function(e) {
            e.stopPropagation();
            // Автоматически генерируем название из первых 20 символов
            const name = content.substring(0, 20) + (content.length > 20 ? '...' : '');
            saveMessageToPromptsWithName(content, name);
            const originalHTML = this.innerHTML;
            this.innerHTML = '<i class="fas fa-check"></i>';
            setTimeout(() => {
                this.innerHTML = originalHTML;
            }, 2000);
        };
        
        buttonsDiv.appendChild(savePromptButton);
    }
    
    contentDiv.appendChild(bubbleDiv);
    contentDiv.appendChild(buttonsDiv);
    
    if (role === 'user') {
        messageDiv.appendChild(contentDiv);
        messageDiv.appendChild(avatarDiv);
    } else {
        messageDiv.appendChild(avatarDiv);
        messageDiv.appendChild(contentDiv);
    }
    
    return messageDiv;
}

function formatText(text) {
    if (!text) return '';
    
    let html = escapeHtml(text);
    
    // Применяем базовое форматирование Markdown
    html = applyMarkdownFormatting(html);
    
    return html;
}

function applyMarkdownFormatting(html) {
    // Заголовки
    html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
    html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');
    
    // Жирный текст
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/__(.+?)__/g, '<strong>$1</strong>');
    
    // Курсив
    html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
    html = html.replace(/_(.+?)_/g, '<em>$1</em>');
    
    // Зачеркнутый текст
    html = html.replace(/~~(.+?)~~/g, '<s>$1</s>');
    
    // Блоки кода
    html = html.replace(/```(\w+)?\n([\s\S]*?)\n```/g, 
        function(match, lang, code) {
            const language = lang ? ` data-language="${lang}"` : '';
            return `<pre><code${language}>${escapeHtml(code.trim())}</code></pre>`;
        });
    
    // Inline код
    html = html.replace(/`(.+?)`/g, '<code>$1</code>');
    
    // Списки
    html = html.replace(/^(\s*)[*-+] (.+)$/gm, function(match, spaces, content) {
        const depth = spaces.length;
        return `<li style="margin-left: ${depth * 20}px">${content}</li>`;
    });
    
    // Обернуть группы li в ul
    html = html.replace(/(<li[^>]*>[\s\S]*?<\/li>)+/g, '<ul>$&</ul>');
    
    // Цитаты
    html = html.replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>');
    
    // Горизонтальные линии
    html = html.replace(/^---$/gm, '<hr>');
    html = html.replace(/^\*\*\*$/gm, '<hr>');
    html = html.replace(/^___$/gm, '<hr>');
    
    // Ссылки
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    
    // Преобразование переносов строк в <br> и параграфы
    html = html.replace(/\n\n+/g, '</p><p>');
    html = html.replace(/\n(?!<\/?(h[1-6]|ul|ol|li|pre|code|blockquote|hr))/g, '<br>');
    
    // Обернуть в параграфы если нет других тегов
    if (!html.match(/^<(p|h[1-6]|ul|ol|li|pre|code|blockquote|hr|div|span|a|strong|em)/i)) {
        html = '<p>' + html + '</p>';
    }
    
    return html;
}

function copyToClipboard(text) {
    if (!text) return;
    
    // 🔧 Убираем HTML-теги, оставляем только чистый текст
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = text;
    const cleanText = tempDiv.textContent || tempDiv.innerText || '';

    navigator.clipboard.writeText(cleanText).then(() => {
        console.log('✅ Текст скопирован');
    }).catch(err => {
        console.error('❌ Ошибка копирования:', err);
        const textArea = document.createElement('textarea');
        textArea.value = cleanText;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
    });
}

function saveMessageToPrompts(content) {
    if (!content || content.trim() === '') {
        alert('Нельзя сохранить пустое сообщение');
        return;
    }
    
    const trimmedContent = content.trim();
    
    // Проверяем, не сохранен ли уже такой промт на сервере
    if (personalPromptsList.some(p => p.content === trimmedContent)) {
        alert('Это сообщение уже сохранено в промтах');
        return;
    }
    
    // Автоматически генерируем название из первых 20 символов
    const name = trimmedContent.substring(0, 20) + (trimmedContent.length > 20 ? '...' : '');
    
    // Сохраняем промт на сервере
    addPromptToServer(trimmedContent, name);
}

// Новая вспомогательная функция для сохранения с именем
function saveMessageToPromptsWithName(content, name) {
    if (!content || content.trim() === '') {
        alert('Нельзя сохранить пустое сообщение');
        return;
    }
    
    const trimmedContent = content.trim();
    
    // Проверяем, не сохранен ли уже такой промт на сервере
    if (personalPromptsList.some(p => p.content === trimmedContent)) {
        alert('Это сообщение уже сохранено в промтах');
        return;
    }
    
    // Сохраняем промт на сервере
    addPromptToServer(trimmedContent, name);
}

function showTypingIndicator() {
    if (!chatContainer) return;
    
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message assistant-message';
    typingDiv.id = 'typing-indicator';
    
    const avatarDiv = document.createElement('div');
    avatarDiv.className = 'avatar assistant-avatar';
    avatarDiv.textContent = '🤖';
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    
    const bubbleDiv = document.createElement('div');
    bubbleDiv.className = 'typing-indicator';
    bubbleDiv.innerHTML = '<span></span><span></span><span></span>';
    
    contentDiv.appendChild(bubbleDiv);
    
    typingDiv.appendChild(avatarDiv);
    typingDiv.appendChild(contentDiv);
    
    chatContainer.appendChild(typingDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

function removeTypingIndicator() {
    const typingIndicator = document.getElementById('typing-indicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

// ================ ФУНКЦИИ ДЛЯ УПРАВЛЕНИЯ БОКОВЫМИ ПАНЕЛЯМИ ================

function toggleChatsSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
        sidebar.classList.toggle('collapsed');
        const collapseBtn = sidebar.querySelector('.collapse-sidebar-btn i');
        if (collapseBtn) {
            if (sidebar.classList.contains('collapsed')) {
                collapseBtn.classList.remove('fa-chevron-left');
                collapseBtn.classList.add('fa-chevron-right');
            } else {
                collapseBtn.classList.add('fa-chevron-left');
                collapseBtn.classList.remove('fa-chevron-right');
            }
        }
    }
}

function togglePromptsSidebar() {
    const promptsSidebar = document.querySelector('.prompts-sidebar');
    if (promptsSidebar) {
        promptsSidebar.classList.toggle('collapsed');
        const collapseBtn = promptsSidebar.querySelector('.collapse-prompts-btn i');
        if (collapseBtn) {
            if (promptsSidebar.classList.contains('collapsed')) {
                collapseBtn.classList.remove('fa-chevron-right');
                collapseBtn.classList.add('fa-chevron-left');
            } else {
                collapseBtn.classList.add('fa-chevron-right');
                collapseBtn.classList.remove('fa-chevron-left');
            }
        }
    }
}
// Функция показа модального окна настроек
function showSettings() {
    const settingsModal = document.getElementById('settingsModal');
    if (settingsModal) {
        settingsModal.style.display = 'flex';
        // Загружаем настройки с сервера при открытии
        if (typeof loadSettingsFromServer === 'function') {
            loadSettingsFromServer();
        }
    }
}

// Функция закрытия модального окна настроек
function closeSettings() {
    const settingsModal = document.getElementById('settingsModal');
    if (settingsModal) {
        settingsModal.style.display = 'none';
    }
}

// Экспорт функций в глобальную область видимости
window.showSettings = showSettings;
window.closeSettings = closeSettings;
// Экспорт функций в глобальную область видимости
window.renderMessagesWithGrouping = renderMessagesWithGrouping;
window.formatChatDate = formatChatDate;
window.addMessageToChat = addMessageToChat;
window.addFormattedMessageToChat = addFormattedMessageToChat;
window.createMessageElement = createMessageElement;
window.createFormattedMessageElement = createFormattedMessageElement;
window.formatText = formatText;
window.applyMarkdownFormatting = applyMarkdownFormatting;
window.copyToClipboard = copyToClipboard;
window.saveMessageToPrompts = saveMessageToPrompts;
window.saveMessageToPromptsWithName = saveMessageToPromptsWithName;
window.showTypingIndicator = showTypingIndicator;
window.removeTypingIndicator = removeTypingIndicator;
window.toggleChatsSidebar = toggleChatsSidebar;
window.togglePromptsSidebar = togglePromptsSidebar;