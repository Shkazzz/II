// file_handlers.js - Работа с файлами

function attachFile() {
    document.getElementById('fileInput').click();
}

// --- ФАЙЛЫ ДЛЯ СООБЩЕНИЯ (Временные, перед отправкой) ---

function handleFileSelect(event) {
    const files = event.target.files;
    const maxSize = 300 * 1024 * 1024; // 300MB
    const allowedTypes = [
        'text/plain', 'application/pdf', 'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'image/jpeg', 'image/jpg', 'image/png', 'image/gif',
        'audio/mpeg', 'video/x-msvideo', 'video/mpeg', 'video/mp4', 'video/webm', 'audio/x-m4a'
    ];

    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        
        if (attachedFiles.length >= 10) {
            alert('Максимальное количество файлов - 10');
            break;
        }
        
        if (file.size > maxSize) {
            alert(`Файл "${file.name}" превышает максимальный размер 300MB`);
            continue;
        }
        
        const isAllowedType = allowedTypes.includes(file.type) || 
                            file.name.match(/\.(txt|pdf|doc|docx|xls|xlsx|jpg|jpeg|png|gif|mp3|avi|mpeg|mp4|webm|m4a|csv)$/i);
        
        if (!isAllowedType) {
            alert(`Файл "${file.name}" имеет неподдерживаемый тип.`);
            continue;
        }
        
        attachedFiles.push(file);
    }

    renderFilePreview();
    event.target.value = ''; // Сброс input
}

function renderFilePreview() {
    if (!filePreview) return;
    filePreview.innerHTML = '';

    if (attachedFiles.length === 0) {
        filePreview.style.display = 'none';
        return;
    }

    filePreview.style.display = 'flex';

    attachedFiles.forEach((file, index) => {
        const fileItem = document.createElement('div');
        fileItem.className = 'file-preview-item';
        
        let fileIcon = 'fa-file';
        let fileClass = '';
        
        if (file.type.includes('image')) {
            fileIcon = 'fa-image';
        } else if (file.type.includes('pdf')) {
            fileIcon = 'fa-file-pdf';
        } else if (file.type.includes('word') || file.name.match(/\.docx?$/i)) {
            fileIcon = 'fa-file-word';
        } else if (file.type.includes('excel') || file.name.match(/\.xlsx?$/i)) {
            fileIcon = 'fa-file-excel';
            fileClass = 'excel';
        } else if (file.type.includes('text') || file.name.match(/\.txt$/i)) {
            fileIcon = 'fa-file-text';
        } else if (file.type.includes('csv') || file.name.match(/\.csv$/i)) {
            fileIcon = 'fa-file-excel';
            fileClass = 'excel';
        }
        
        fileItem.innerHTML = `
            <i class="fas ${fileIcon} file-preview-icon ${fileClass}"></i>
            <span class="file-preview-name">${escapeHtml(file.name)}</span>
            <span class="file-preview-size">(${formatFileSize(file.size)})</span>
            <button class="file-preview-remove" data-index="${index}" title="Удалить">×</button>
        `;
        
        fileItem.querySelector('.file-preview-remove').onclick = function(e) {
            e.stopPropagation();
            const idx = parseInt(this.getAttribute('data-index')); 
            attachedFiles.splice(idx, 1);
            renderFilePreview();
        };
        
        filePreview.appendChild(fileItem);
    });
}

function formatFileSize(bytes) {
    if (bytes === 0 || isNaN(bytes)) return '0 Б';
    const k = 1024;
    const sizes = ['Б', 'КБ', 'МБ', 'ГБ'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function clearAttachedFiles() {
    attachedFiles = [];
    if (filePreview) {
        filePreview.innerHTML = '';
        filePreview.style.display = 'none';
    }
    if (fileInput) {
        fileInput.value = '';
    }
}

// === ФАЙЛЫ ЧАТА (Правая панель) ===
let chatFilesList = [];


async function loadChatFiles(chatId) {
    if (!chatId || !authToken) {
        chatFilesList = [];
        renderChatFiles();
        return;
    }
    const formData = new FormData();
    formData.append('access_token', authToken);
    formData.append('chat', chatId);
    
    
    console.log(`📂 Загрузка файлов для чата: ${chatId}`); // 👈 Добавить это

    //try {
   //     const response = await $.ajax({
   //         url: `${API_BASE_URL}/api/v1.1/route_files/get_chat_files`,
    //        method: 'POST',
   //         contentType: 'application/json',
   //         data:formData
     //   });




 $.ajax({
            url: `${API_BASE_URL}/api/v1.1/route_files/get_chat_files`,
            method: 'POST', // или 'GET' — уточните в документации вашего API
            data: formData,
            processData: false,
            contentType: false,
            success: function(res) {
                console.log(res)
            
        //    error: function(err) {
         //       console.error('❌ Ошибка при опросе результата:', err);
        //                        
         }
        });



























        
        //console.log(`📥 Ответ сервера для чата ${chatId}:`, response); // 👈 Добавить это

       // if (response.status === 0 && Array.isArray(response.files)) {
       //     chatFilesList = response.files.map(file => ({
       //         id: file.id || file.name,
       //         name: file.name,
       //         size: file.size || 0,
       //         type: getFileType(file.name),
       //         selected: false
       //     }));
      //  } else {
      //      chatFilesList = [];
     //   }
   // } catch (e) {
   //     console.error('Ошибка загрузки файлов:', e);
  //      chatFilesList = [];
  //  }

   // renderChatFiles();
}

function getFileType(filename) {
    const ext = filename.split('.').pop().toLowerCase();
    const typeMap = {
        'txt': 'text', 'pdf': 'pdf', 'doc': 'word', 'docx': 'word',
        'xls': 'excel', 'xlsx': 'excel', 'csv': 'excel',
        'jpg': 'image', 'jpeg': 'image', 'png': 'image', 'gif': 'image',
        'mp3': 'audio', 'mp4': 'video', 'avi': 'video', 'webm': 'video'
    };
    return typeMap[ext] || 'file';
}

function getFileIcon(fileType) {
    const iconMap = {
        'text': 'fa-file-alt', 'pdf': 'fa-file-pdf', 'word': 'fa-file-word',
        'excel': 'fa-file-excel', 'image': 'fa-file-image', 'audio': 'fa-file-audio',
        'video': 'fa-file-video', 'file': 'fa-file'
    };
    return iconMap[fileType] || 'fa-file';
}

function renderChatFiles() {
    const container = document.getElementById('chatFilesList');
    const deleteBtn = document.querySelector('.delete-files-btn');
    if (!container) return;
    
    container.innerHTML = '';
    
    if (chatFilesList.length === 0) {
        container.innerHTML = '<div class="empty-files"><p>Нет загруженных файлов</p></div>';
        if (deleteBtn) deleteBtn.style.display = 'none';
        return;
    }
    
    chatFilesList.forEach((file, index) => {
        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';
        
        const icon = getFileIcon(file.type);
        const size = formatFileSize(file.size);
        
        fileItem.innerHTML = `
            <input type="checkbox" 
                   class="file-checkbox" 
                   data-index="${index}" 
                   ${file.selected ? 'checked' : ''}>
            <i class="fas ${icon} file-icon file-type-${file.type}"></i>
            <div class="file-info">
                <div class="file-name" title="${escapeHtml(file.name)}">${escapeHtml(file.name)}</div>
                <div class="file-size">${size}</div>
            </div>
        `;
        
        const checkbox = fileItem.querySelector('.file-checkbox');
        checkbox.addEventListener('change', function() {
            chatFilesList[index].selected = this.checked;
            updateDeleteButton();
        });
        
        container.appendChild(fileItem);
    });
    
    updateDeleteButton();
}

function updateDeleteButton() {
    const deleteBtn = document.querySelector('.delete-files-btn');
    if (!deleteBtn) return;
    
    const hasSelected = chatFilesList.some(f => f.selected);
    deleteBtn.style.display = hasSelected ? 'flex' : 'none';
    
    if (hasSelected) {
        const count = chatFilesList.filter(f => f.selected).length;
        deleteBtn.innerHTML = `<i class="fas fa-trash"></i> Удалить выбранное (${count})`;
    }
}

// ✅ ИСПРАВЛЕНО: используем form-urlencoded для удаления
async function deleteSelectedFiles() {
    const selectedFiles = chatFilesList.filter(f => f.selected);
    if (selectedFiles.length === 0) {
        alert('Выберите файлы для удаления');
        return;
    }
    
    if (!confirm(`Удалить ${selectedFiles.length} файл(ов)?`)) {
        return;
    }
    
    try {
        const response = await $.ajax({
            url: `${API_BASE_URL}/api/v1.1/route_files/delete_chat_files`,
            method: 'POST',
            contentType: 'application/x-www-form-urlencoded', // ✅ Правильный Content-Type
            data: `access_token=${encodeURIComponent(authToken)}&chat=${encodeURIComponent(currentChatId)}&files=${encodeURIComponent(JSON.stringify(selectedFiles.map(f => f.name)))}`
        });
        
        if (response.status === 0) {
            chatFilesList = chatFilesList.filter(f => !f.selected);
            renderChatFiles();
            alert('Файлы успешно удалены');
        } else {
            alert('Ошибка при удалении файлов: ' + (response.descr || 'Неизвестная ошибка'));
        }
    } catch (e) {
        console.error('Ошибка удаления файлов:', e);
        alert('Ошибка при удалении файлов');
    }
}

function triggerFileUpload() {
    let chatFileInput = document.getElementById('chatFileInput');
    if (!chatFileInput) {
        chatFileInput = document.createElement('input');
        chatFileInput.type = 'file';
        chatFileInput.id = 'chatFileInput';
        chatFileInput.multiple = true;
        chatFileInput.style.display = 'none';
        document.body.appendChild(chatFileInput);
        
        chatFileInput.addEventListener('change', function(e) {
            if (e.target.files.length > 0) {
                handleChatFileUpload(e.target.files);
            }
            e.target.value = '';
        });
    }
    chatFileInput.click();
}

async function handleChatFileUpload(files) {
    if (!currentChatId || !files.length || !authToken) {
        alert('Выберите чат перед загрузкой файлов');
        return;
    }
    
    const formData = new FormData();
    formData.append('access_token', authToken);
    formData.append('chat', currentChatId);
    Array.from(files).forEach(f => formData.append('files', f));
    
    try {
        await $.ajax({
            url: `${API_BASE_URL}/api/v1.1/route_files/upload_chat_files`,
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false
        });
        loadChatFiles(currentChatId);
    } catch (e) {
        alert('Ошибка загрузки файлов на сервер');
    }
}

// Экспорт функций
window.getFileType = getFileType;
window.getFileIcon = getFileIcon;
window.attachFile = attachFile;
window.handleFileSelect = handleFileSelect;
window.renderFilePreview = renderFilePreview;
window.formatFileSize = formatFileSize;
window.clearAttachedFiles = clearAttachedFiles;
window.loadChatFiles = loadChatFiles;
window.renderChatFiles = renderChatFiles;
window.triggerFileUpload = triggerFileUpload;
window.handleChatFileUpload = handleChatFileUpload;
window.deleteSelectedFiles = deleteSelectedFiles;